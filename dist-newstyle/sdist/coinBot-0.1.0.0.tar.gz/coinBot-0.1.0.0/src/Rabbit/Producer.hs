{-# LANGUAGE OverloadedStrings #-}
module Rabbit.Producer where

import Network.AMQP
import qualified Data.ByteString.Lazy.Char8 as BL
