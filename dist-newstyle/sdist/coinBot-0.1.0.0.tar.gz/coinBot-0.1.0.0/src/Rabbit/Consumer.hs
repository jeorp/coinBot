{-# LANGUAGE OverloadedStrings #-}
module Rabbit.Consumer where

import Network.AMQP
import qualified Data.ByteString.Lazy.Char8 as BL
