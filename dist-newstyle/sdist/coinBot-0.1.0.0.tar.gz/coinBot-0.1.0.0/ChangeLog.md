# Changelog for coinBot

## Unreleased changes
