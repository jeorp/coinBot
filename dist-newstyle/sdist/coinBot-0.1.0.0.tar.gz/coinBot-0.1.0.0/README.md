# GMOcoin API + DiscordBot sample (Now developing..)

How to use
1. get each token.
2. add config.env to project root as below.


entry:https://discord.com/api/webhooks/WWWWWWW  
discord_bot_token:XXXXXXXXXXX    
gmo_api_key:YYYYYYYYYY   
gmo_api_secret:ZZZZZZZZZZZZZZZZZZZZ

3. build and run.
 